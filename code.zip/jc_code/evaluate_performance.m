function metrics = evaluate_performance(predictions, true_labels)
    % Calculate performance metrics
    
    % Ensure same size
    [rows, cols] = size(true_labels);
    if size(predictions, 1) ~= rows || size(predictions, 2) ~= cols
        predictions = imresize(predictions, [rows, cols], 'nearest');
    end
    
    % Convert to vectors
    pred_flat = double(predictions(:));
    true_flat = double(true_labels(:));
    
    % Remove invalid pixels (background)
    valid = true_flat > 0;
    pred_flat = pred_flat(valid);
    true_flat = true_flat(valid);
    
    % Number of classes
    num_classes = max(true_flat);
    
    % Initialize confusion matrix
    confusion = zeros(num_classes, num_classes);
    
    for i = 1:length(true_flat)
        t = true_flat(i);
        p = pred_flat(i);
        if t <= num_classes && p <= num_classes
            confusion(t, p) = confusion(t, p) + 1;
        end
    end
    
    % Calculate metrics
    % Overall Accuracy
    metrics.overall_accuracy = sum(diag(confusion)) / sum(confusion(:));
    
    % Average Accuracy
    class_acc = zeros(num_classes, 1);
    for c = 1:num_classes
        class_acc(c) = confusion(c, c) / max(sum(confusion(c, :)), 1);
    end
    metrics.average_accuracy = mean(class_acc);
    
    % Precision, Recall, F-measure
    precision = zeros(num_classes, 1);
    recall = zeros(num_classes, 1);
    fmeasure = zeros(num_classes, 1);
    
    for c = 1:num_classes
        tp = confusion(c, c);
        fp = sum(confusion(:, c)) - tp;
        fn = sum(confusion(c, :)) - tp;
        
        precision(c) = tp / max(tp + fp, 1);
        recall(c) = tp / max(tp + fn, 1);
        fmeasure(c) = 2 * precision(c) * recall(c) / max(precision(c) + recall(c), 1);
    end
    
    metrics.precision = mean(precision);
    metrics.recall = mean(recall);
    metrics.fmeasure = mean(fmeasure);
    
    % Cohen's Kappa
    p0 = metrics.overall_accuracy;
    pe = sum(sum(confusion, 1) .* sum(confusion, 2)) / sum(confusion(:))^2;
    metrics.cohens_kappa = (p0 - pe) / (1 - pe);
    
    % False Negative Rate
    fnr = zeros(num_classes, 1);
    for c = 1:num_classes
        fn = sum(confusion(c, :)) - confusion(c, c);
        fnr(c) = fn / max(sum(confusion(c, :)), 1);
    end
    metrics.fnr = mean(fnr);
end