function visualize_results(original_img, true_labels, predictions)
    % Visualize classification results
    
    figure('Position', [100, 100, 1200, 400]);
    
    % Original RGB composite
    subplot(1, 3, 1);
    if size(original_img, 3) >= 3
        rgb_img = cat(3, original_img(:, :, 30), original_img(:, :, 20), original_img(:, :, 10));
        rgb_img = (rgb_img - min(rgb_img(:))) / (max(rgb_img(:)) - min(rgb_img(:)));
        imshow(rgb_img);
        title('Original RGB Composite');
    else
        imshow(original_img, []);
        title('Original Image');
    end
    
    % Ground Truth
    subplot(1, 3, 2);
    imagesc(true_labels);
    colormap(gca, jet(max(true_labels(:))));
    colorbar;
    title('Ground Truth');
    axis equal;
    
    % Predictions
    subplot(1, 3, 3);
    imagesc(predictions);
    colormap(gca, jet(max(true_labels(:))));
    colorbar;
    title('CASEO_3D-DCNN Predictions');
    axis equal;
    
    sgtitle('Hyperspectral Crop Identification Results');
    
    % Confusion Matrix
    figure('Position', [100, 500, 600, 500]);
    
    [rows, cols] = size(true_labels);
    if size(predictions, 1) ~= rows || size(predictions, 2) ~= cols
        predictions = imresize(predictions, [rows, cols], 'nearest');
    end
    
    pred_flat = double(predictions(:));
    true_flat = double(true_labels(:));
    valid = true_flat > 0;
    pred_flat = pred_flat(valid);
    true_flat = true_flat(valid);
    
    num_classes = max(true_flat);
    confusion = zeros(num_classes, num_classes);
    
    for i = 1:length(true_flat)
        t = true_flat(i);
        p = pred_flat(i);
        if t <= num_classes && p <= num_classes
            confusion(t, p) = confusion(t, p) + 1;
        end
    end
    
    % Normalize confusion matrix
    confusion_norm = confusion ./ max(sum(confusion, 2), 1);
    
    imagesc(confusion_norm);
    colormap(gca, jet);
    colorbar;
    
    class_names = arrayfun(@(x) ['Class ', num2str(x)], 1:num_classes, 'UniformOutput', false);
    set(gca, 'XTick', 1:num_classes, 'XTickLabel', class_names);
    set(gca, 'YTick', 1:num_classes, 'YTickLabel', class_names);
    xlabel('Predicted');
    ylabel('True');
    title('Confusion Matrix (Normalized)');
end