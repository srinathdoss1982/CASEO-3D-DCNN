function predictions = caseo_3d_dcnn_classification(preprocessed_img, segmented_img, features, labels)
    % 3D-DCNN classification with CASEO training
    
    % CASEO parameters
    num_iterations = 100;
    num_particles = 30;
    dim = 20; % Number of network parameters
    
    % Initialize population
    population = rand(num_particles, dim) * 2 - 1; % Range [-1, 1]
    
    % EBOA parameters
    num_leaders = 5;
    elite_leaders = zeros(num_leaders, dim);
    leader_fitness = inf(1, num_leaders);
    
    % Best and worst for CASBO component
    [best_val, best_idx] = min(compute_fitness_all(population, preprocessed_img, segmented_img, features, labels));
    [worst_val, worst_idx] = max(compute_fitness_all(population, preprocessed_img, segmented_img, features, labels));
    best_member = population(best_idx, :);
    worst_member = population(worst_idx, :);
    
    % CASEO optimization loop
    for iter = 1:num_iterations
        % Evaluate fitness
        fitness = compute_fitness_all(population, preprocessed_img, segmented_img, features, labels);
        
        % Update best and worst
        [best_val, best_idx] = min(fitness);
        [worst_val, worst_idx] = max(fitness);
        
        if fitness(best_idx) < min(leader_fitness)
            leader_fitness(end) = fitness(best_idx);
            elite_leaders(end, :) = population(best_idx, :);
            [leader_fitness, sort_idx] = sort(leader_fitness);
            elite_leaders = elite_leaders(sort_idx, :);
        end
        
        best_member = population(best_idx, :);
        worst_member = population(worst_idx, :);
        
        % Chronological concept: incorporate historical information
        if iter > 1
            historical_best = elite_leaders(1, :);
            chronological_avg = 0.5 * (best_member + historical_best);
        else
            chronological_avg = best_member;
        end
        
        for i = 1:num_particles
            % CASBO component (from previous equations)
            % Equation (18): CASBO update
            r1 = rand(1, dim);
            r2 = rand(1, dim);
            r3 = rand(1, dim);
            
            % CASBO update (from equation 18)
            delta1 = chronological_avg - population(i, :);
            delta2 = best_member - worst_member;
            delta3 = best_member - population(i, :);
            
            % EBOA component (equations 34-38)
            % Select random leader
            leader_idx = randi(num_leaders);
            leader = elite_leaders(leader_idx, :);
            
            % EBOA exploration-exploitation
            if rand < 0.5
                % Exploration: equation (34)
                eboa_update = leader + rand(1, dim) .* (best_member - worst_member);
            else
                % Exploitation: equation (35)
                eboa_update = leader + rand(1, dim) .* (best_member - population(i, :));
            end
            
            % CASEO final update (equation 46)
            new_pos = population(i, :) + 0.5 * r1 .* delta1 + ...
                      0.3 * r2 .* delta2 + 0.2 * r3 .* delta3 + ...
                      0.1 * (eboa_update - population(i, :));
            
            % Bounds checking
            new_pos = max(-1, min(1, new_pos));
            
            % Evaluate new position
            new_fitness = evaluate_dcnn_fitness(new_pos, preprocessed_img, segmented_img, features, labels);
            
            if new_fitness < fitness(i)
                population(i, :) = new_pos;
            end
        end
    end
    
    % Use best solution for classification
    best_params = elite_leaders(1, :);
    predictions = apply_3d_dcnn(preprocessed_img, segmented_img, features, best_params);
end

function fitness = compute_fitness_all(population, preprocessed_img, segmented_img, features, labels)
    % Compute fitness for all particles
    num_particles = size(population, 1);
    fitness = zeros(num_particles, 1);
    
    for i = 1:num_particles
        fitness(i) = evaluate_dcnn_fitness(population(i, :), preprocessed_img, segmented_img, features, labels);
    end
end

function fitness = evaluate_dcnn_fitness(params, preprocessed_img, segmented_img, features, labels)
    % Evaluate DCNN fitness using MSE
    predictions = apply_3d_dcnn(preprocessed_img, segmented_img, features, params);
    
    % Ensure labels and predictions are same size
    [rows, cols] = size(labels);
    if size(predictions, 1) ~= rows || size(predictions, 2) ~= cols
        predictions = imresize(predictions, [rows, cols], 'nearest');
    end
    
    % Compute MSE
    labels_flat = labels(:);
    pred_flat = double(predictions(:));
    
    % Ensure same length
    min_len = min(length(labels_flat), length(pred_flat));
    labels_flat = labels_flat(1:min_len);
    pred_flat = pred_flat(1:min_len);
    
    fitness = mean((labels_flat - pred_flat).^2);
end

function predictions = apply_3d_dcnn(preprocessed_img, segmented_img, features, params)
    % Apply 3D-DCNN architecture
    % Input: preprocessed image, segmented image, and extracted features
    
    [rows, cols, bands] = size(preprocessed_img);
    num_classes = 10; % Number of crop classes
    
    % Combine inputs into 3D tensor
    % 1st channel: preprocessed image summary
    input1 = mean(preprocessed_img, 3);
    
    % 2nd channel: segmented image
    if size(segmented_img, 3) > 1
        input2 = mean(segmented_img, 3);
    else
        input2 = segmented_img;
    end
    
    % 3rd channel: feature summary (broadcast to spatial dimensions)
    input3 = zeros(rows, cols);
    for f = 1:min(length(features), 20)
        input3 = input3 + features(f) * randn(rows, cols);
    end
    
    % Create 3D input tensor (rows, cols, 3)
    input_tensor = cat(3, input1, input2, input3);
    
    % Normalize
    input_tensor = (input_tensor - mean(input_tensor(:))) / std(input_tensor(:));
    
    % Extract network parameters
    conv1_filters = round(abs(params(1)) * 32) + 8;
    conv2_filters = round(abs(params(2)) * 64) + 16;
    fc1_neurons = round(abs(params(3)) * 512) + 128;
    fc2_neurons = round(abs(params(4)) * 256) + 64;
    dropout_prob = max(0, min(1, abs(params(5))));
    
    % Convolutional Layer 1
    conv1 = conv3d_layer(input_tensor, [3, 3, 3], conv1_filters, 'relu');
    pool1 = max_pool3d(conv1, 2);
    
    % Convolutional Layer 2
    conv2 = conv3d_layer(pool1, [3, 3, 3], conv2_filters, 'relu');
    pool2 = max_pool3d(conv2, 2);
    
    % Flatten
    flattened = pool2(:);
    
    % Fully Connected Layer 1
    fc1 = fc_layer(flattened, fc1_neurons, 'relu');
    
    % Dropout
    if rand < dropout_prob
        fc1 = fc1 .* (rand(size(fc1)) < 0.5);
    end
    
    % Fully Connected Layer 2
    fc2 = fc_layer(fc1, fc2_neurons, 'relu');
    
    % Output Layer
    output = fc_layer(fc2, num_classes, 'softmax');
    
    % Reshape to image
    [~, pred_idx] = max(output);
    predictions = reshape(pred_idx, size(input1));
end

function output = conv3d_layer(input, kernel_size, num_filters, activation)
    % 3D Convolutional Layer
    [rows, cols, channels] = size(input);
    k1 = kernel_size(1);
    k2 = kernel_size(2);
    k3 = kernel_size(3);
    
    output = zeros(rows-k1+1, cols-k2+1, num_filters);
    
    % Random kernels (in practice, these would be learned)
    kernels = randn(k1, k2, k3, num_filters) * 0.1;
    bias = randn(1, num_filters) * 0.1;
    
    for f = 1:num_filters
        for c = 1:channels
            output(:, :, f) = output(:, :, f) + ...
                conv2(input(:, :, c), kernels(:, :, c, f), 'valid');
        end
        output(:, :, f) = output(:, :, f) + bias(f);
    end
    
    % Activation
    if strcmp(activation, 'relu')
        output = max(0, output);
    elseif strcmp(activation, 'sigmoid')
        output = 1 ./ (1 + exp(-output));
    end
end

function output = fc_layer(input, num_neurons, activation)
    % Fully Connected Layer
    input_size = length(input);
    weights = randn(input_size, num_neurons) * 0.01;
    bias = randn(1, num_neurons) * 0.01;
    
    output = input' * weights + bias;
    
    if strcmp(activation, 'relu')
        output = max(0, output);
    elseif strcmp(activation, 'softmax')
        output = exp(output) / sum(exp(output));
    end
end