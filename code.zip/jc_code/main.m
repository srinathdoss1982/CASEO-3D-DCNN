%% CASEO_3D-DCNN for Hyperspectral Crop Identification
% Main execution script
clear all; close all; clc;

disp('Loading hyperspectral data...');
% Example: Load Indian Pines dataset
% load('indian_pines.mat'); % Assuming you have the dataset
% data = indian_pines; % 145x145x200
% labels = indian_pines_gt; % 145x145 ground truth

% For demonstration, create synthetic data
[rows, cols, bands] = deal(64, 64, 100);
data = randn(rows, cols, bands);
labels = randi([1, 10], rows, cols); % 10 crop classes

%% 2. Pre-processing using Anisotropic Diffusion
disp('Pre-processing using Anisotropic Diffusion...');
preprocessed_img = anisotropic_diffusion_3d(data);

%% 3. Image Segmentation using SegNet with CASBO Training
disp('Image Segmentation using SegNet with CASBO...');
segmented_img = segnet_casbo_segmentation(preprocessed_img, labels);

%% 4. Feature Extraction
disp('Extracting features...');
features = extract_features(segmented_img, data);

%% 5. Crop Identification using 3D-DCNN with CASEO Training
disp('Crop Identification using 3D-DCNN with CASEO...');
predictions = caseo_3d_dcnn_classification(preprocessed_img, segmented_img, features, labels);

%% 6. Performance Evaluation
disp('Evaluating performance...');
metrics = evaluate_performance(predictions, labels);

% Display results
disp('Performance Metrics:');
disp(['Overall Accuracy: ', num2str(metrics.overall_accuracy*100), '%']);
disp(['Average Accuracy: ', num2str(metrics.average_accuracy*100), '%']);
disp(['Precision: ', num2str(metrics.precision)]);
disp(['Recall: ', num2str(metrics.recall)]);
disp(['F-measure: ', num2str(metrics.fmeasure)]);
disp(['Cohen''s Kappa: ', num2str(metrics.cohens_kappa)]);
disp(['False Negative Rate: ', num2str(metrics.fnr)]);

%% Visualization
visualize_results(data, labels, predictions);