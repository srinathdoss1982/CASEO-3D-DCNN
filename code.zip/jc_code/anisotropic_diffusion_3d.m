function diffused_img = anisotropic_diffusion_3d(img)
    % 3D Anisotropic Diffusion for noise removal while preserving edges
    % Parameters
    num_iterations = 10;
    kappa = 30;
    lambda = 0.25;
    
    % Initialize
    diffused_img = img;
    [rows, cols, bands] = size(img);
    
    for iter = 1:num_iterations
        % Compute gradients in all dimensions
        for b = 1:bands
            % 2D spatial gradients within each band
            [grad_x, grad_y] = gradient(squeeze(diffused_img(:, :, b)));
            
            % Compute gradient magnitude
            grad_mag = sqrt(grad_x.^2 + grad_y.^2);
            
            % Compute conduction coefficient (edge-stopping function)
            conduction = exp(-(grad_mag/kappa).^2);
            
            % Apply diffusion
            diff_x = conduction .* grad_x;
            diff_y = conduction .* grad_y;
            
            % Update image
            diffused_img(:, :, b) = squeeze(diffused_img(:, :, b)) + ...
                lambda * (divergence(diff_x, diff_y));
        end
        
        % Spectral gradient (across bands)
        for r = 1:rows
            for c = 1:cols
                if bands > 1
                    grad_z = diffused_img(r, c, 2:end) - diffused_img(r, c, 1:end-1);
                    grad_mag_z = sqrt(grad_z.^2);
                    conduction_z = exp(-(grad_mag_z/kappa).^2);
                    
                    diffused_img(r, c, 2:end-1) = diffused_img(r, c, 2:end-1) + ...
                        lambda * (conduction_z(2:end) .* grad_z(2:end) - ...
                        conduction_z(1:end-1) .* grad_z(1:end-1));
                end
            end
        end
    end
end

function div = divergence(grad_x, grad_y)
    [rows, cols] = size(grad_x);
    div = zeros(rows, cols);
    
    % Compute divergence
    for i = 2:rows-1
        for j = 2:cols-1
            div(i,j) = (grad_x(i+1,j) - grad_x(i-1,j))/2 + ...
                       (grad_y(i,j+1) - grad_y(i,j-1))/2;
        end
    end
end