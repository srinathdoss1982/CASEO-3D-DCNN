function features = extract_features(segmented_img, original_img)
    % Extract spectral-spatial features and vegetation indices
    
    % 3.4.1 Spectral Spatial Features
    % 1. Multi-texton (MTH)
    mth_features = extract_multitexton(segmented_img);
    
    % 2. LBP (Local Binary Pattern)
    lbp_features = extract_lbp(segmented_img);
    
    % 3. LGXP (Local Gabor XOR Pattern)
    lgxp_features = extract_lgxp(segmented_img);
    
    % 3.4.2 Vegetation Indices
    % 4. RVI, NDVI, EVI, WDRVI
    vi_features = extract_vegetation_indices(original_img);
    
    % Combine all features
    features = [mth_features, lbp_features, lgxp_features, vi_features];
end

function mth_features = extract_multitexton(img)
    % Multi-texton histogram feature extraction
    [rows, cols, bands] = size(img);
    
    % Gridding: Divide image into smaller blocks
    grid_size = 8;
    num_blocks_row = floor(rows / grid_size);
    num_blocks_col = floor(cols / grid_size);
    
    % For each band, compute texton histogram
    mth_features = [];
    
    for b = 1:min(bands, 10) % Use first 10 bands for efficiency
        band_img = squeeze(img(:, :, b));
        
        % Gridding
        block_hist = zeros(1, 256);
        for i = 1:num_blocks_row
            for j = 1:num_blocks_col
                block = band_img((i-1)*grid_size+1:i*grid_size, ...
                                 (j-1)*grid_size+1:j*grid_size);
                block_hist = block_hist + histcounts(block(:), 0:256);
            end
        end
        
        % Normalize
        block_hist = block_hist / sum(block_hist);
        mth_features = [mth_features, block_hist];
    end
end

function lbp_features = extract_lbp(img)
    % LBP feature extraction
    [rows, cols, bands] = size(img);
    
    lbp_features = [];
    
    for b = 1:min(bands, 10)
        band_img = squeeze(img(:, :, b));
        
        % Circular neighborhood
        radius = 1;
        neighbors = 8;
        
        % Compute LBP
        lbp_img = zeros(rows, cols);
        for i = radius+1:rows-radius
            for j = radius+1:cols-radius
                center = band_img(i, j);
                lbp_code = 0;
                for n = 1:neighbors
                    angle = (n-1) * 2*pi/neighbors;
                    x = round(i + radius * cos(angle));
                    y = round(j + radius * sin(angle));
                    if x >= 1 && x <= rows && y >= 1 && y <= cols
                        if band_img(x, y) > center
                            lbp_code = lbp_code + 2^(n-1);
                        end
                    end
                end
                lbp_img(i, j) = lbp_code;
            end
        end
        
        % Histogram of LBP
        lbp_hist = histcounts(lbp_img(:), 0:256);
        lbp_hist = lbp_hist / sum(lbp_hist);
        lbp_features = [lbp_features, lbp_hist];
    end
end

function lgxp_features = extract_lgxp(img)
    % LGXP feature extraction
    [rows, cols, bands] = size(img);
    
    lgxp_features = [];
    
    for b = 1:min(bands, 10)
        band_img = squeeze(img(:, :, b));
        
        % Gabor filter bank
        orientations = 8;
        scales = 5;
        
        for o = 1:orientations
            for s = 1:scales
                % Create Gabor filter
                wavelength = 2^s;
                orientation = (o-1) * pi / orientations;
                gabor_kernel = gabor_filter(wavelength, orientation);
                
                % Apply Gabor filter
                filtered = conv2(band_img, gabor_kernel, 'same');
                
                % Extract phase information
                phase = angle(filtered);
                
                % Quantize phase
                quantized = round(phase / (pi/4));
                quantized = mod(quantized, 8);
                
                % LXP operator on quantized phase
                lgxp_hist = histcounts(quantized(:), -1:8);
                lgxp_hist = lgxp_hist / sum(lgxp_hist);
                lgxp_features = [lgxp_features, lgxp_hist];
            end
        end
    end
end

function gabor_kernel = gabor_filter(wavelength, orientation)
    % Create Gabor filter kernel
    sigma = wavelength * 0.56;
    gamma = 0.5;
    size_kernel = round(4 * sigma);
    
    [x, y] = meshgrid(-size_kernel:size_kernel, -size_kernel:size_kernel);
    
    % Rotate coordinates
    x_rot = x * cos(orientation) + y * sin(orientation);
    y_rot = -x * sin(orientation) + y * cos(orientation);
    
    % Gabor function
    gabor_kernel = exp(-(x_rot.^2 + gamma^2 * y_rot.^2) / (2 * sigma^2)) .* ...
                   cos(2 * pi * x_rot / wavelength + pi/2);
    
    % Normalize
    gabor_kernel = gabor_kernel - mean(gabor_kernel(:));
    gabor_kernel = gabor_kernel / sum(gabor_kernel(:));
end

function vi_features = extract_vegetation_indices(img)
    % Extract vegetation indices
    % Assuming NIR band is at index 'nir_idx' and Red band at 'red_idx'
    % For Indian Pines: NIR ~ band 50-100, Red ~ band 30-40
    
    [~, ~, bands] = size(img);
    
    % Determine band indices (these would be specified by the dataset)
    nir_idx = round(bands * 0.6); % Approximate NIR band
    red_idx = round(bands * 0.3); % Approximate Red band
    blue_idx = round(bands * 0.15); % Approximate Blue band
    
    % Extract bands
    nir = double(squeeze(img(:, :, nir_idx)));
    red = double(squeeze(img(:, :, red_idx)));
    blue = double(squeeze(img(:, :, blue_idx)));
    
    % Avoid division by zero
    epsilon = 1e-10;
    
    % 1. Ratio Vegetation Index (RVI)
    rvi = nir ./ (red + epsilon);
    rvi_feat = mean(rvi(:));
    
    % 2. Normalized Difference Vegetation Index (NDVI)
    ndvi = (nir - red) ./ (nir + red + epsilon);
    ndvi_feat = mean(ndvi(:));
    
    % 3. Enhanced Vegetation Index (EVI)
    G = 2.5;
    C1 = 6;
    C2 = 7.5;
    L = 1;
    evi = G * (nir - red) ./ (nir + C1*red - C2*blue + L + epsilon);
    evi_feat = mean(evi(:));
    
    % 4. Wide Dynamic Range Vegetation Index (WDRVI)
    alpha = 0.1; % Weighting factor
    wdrvi = (alpha * nir - red) ./ (alpha * nir + red + epsilon);
    wdrvi_feat = mean(wdrvi(:));
    
    vi_features = [rvi_feat, ndvi_feat, evi_feat, wdrvi_feat];
end